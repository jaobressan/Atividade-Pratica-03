package interfaces;
public interface Trabalhavel {
 public   void trabalhar();
    public void relatarProgresso();
}


